import os
import helper as Helper

folder_path = 'pdfs'
index = 0
for filename in os.listdir(folder_path):
    if filename.endswith('.pdf'):
        if index == 0:
            db = Helper.create_db_from_pdf(os.path.join(folder_path, filename))
            # print (db.docstore._dict.Document)
            index+=1
        else:
            db_i = Helper.create_db_from_pdf(os.path.join(folder_path, filename))
            db.merge_from(db_i)
            index+=1

        print ("read ", index, " documents")
    
    db.save_local('db')
    

        