from langchain_community.document_loaders import PyMuPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.azure_openai import AzureOpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.llms import AzureOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from dotenv import load_dotenv


load_dotenv()
embeddings = AzureOpenAIEmbeddings(azure_deployment="ada001")


def create_db_from_pdf(pdf_path: str) -> FAISS:
    loader = PyMuPDFLoader(pdf_path)
    data = loader.load()

    db = FAISS.from_documents(data, embeddings)
    return db

def get_response_from_query(query, k=4):
    db = FAISS.load_local("db", embeddings)
    docs = db.similarity_search(query, k=k)
    docs_page_content = " ".join([d.page_content for d in docs])
    llm = AzureOpenAI(deployment_name="gpt35-instruct",model_name="gpt-35-turbo-instruct",temperature=0,max_tokens=5000)

    prompt = PromptTemplate(
        input_variables=["question", "docs"],
        template="""
        
        Answer Based on Provided Texts: 
        When you receive a science question, search the provided science texts and documents using the RAG system. 
        Base your answer solely on the information found in these texts. 
        
        Accuracy and Relevance: 
        Ensure that your responses are accurate and relevant to the question asked. 
        Your answers should reflect the content and context of the provided science texts. 
        
        Admitting Lack of Information: 
        If the information necessary to answer a question is not available in the provided texts, respond with \"I don't know.\" 
        Do not attempt to infer, guess, or provide information outside the scope of the provided texts. 
        
        Citing Sources: 
        When providing an answer, cite the specific text or document from the provided materials. 
        This will help in validating the response and maintaining transparency.
        
        Answer the following question: {question}
        By searching the following textbook text: {docs}

        """,
    )

    chain = LLMChain(llm=llm, prompt=prompt)
    response = chain.run(question=query, docs=docs_page_content)
    response = response.replace("\n", "")
    return response, docs