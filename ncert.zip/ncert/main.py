import streamlit as st
import helper as helper
import textwrap
from langchain.vectorstores import FAISS
import json

st.title("Student Assistant")

with st.sidebar:
    with st.form(key='my_form'):
        question = st.sidebar.text_area(
            label="What is your Question ?",
            max_chars=50
            )
        grade = st.sidebar.selectbox(
            label="Select Grade",
            options=['VI','VII','VIII','IX','X']
            )
        submit_button = st.form_submit_button(label='Submit')

if question:
    if grade != "VIII":
        st.subheader("Sorry, we only support VIII grade for now.")
        st.stop()
    else:
        response,docs = helper.get_response_from_query(question)
        st.subheader("Answer:")
        st.text(textwrap.fill(response, width=85))

        st.subheader("Reference:")
        reference_text = ""
        for doc in docs:
            reference_text = reference_text + " Source : " + doc.metadata["source"] + " Page : " + str(doc.metadata["page"]) + " <a href='https://edudocsx.blob.core.windows.net/" + doc.metadata["source"] + "#page=" + str(doc.metadata["page"]) + "'>Link</a>Title : " + doc.metadata["title"] + " Title : " + doc.metadata["title"] + " Author : " + doc.metadata["author"] + "\n\n"

        st.text(reference_text)

        st.subheader("Reference Text: Showing only first page due to brevity.")
        st.text(textwrap.fill(docs[0].page_content, width=85))